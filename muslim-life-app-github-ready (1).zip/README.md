# Muslim Life App - GitHub Ready

This is a React (Vite) project with:

- Quran (short surahs) with Arabic + Hindi translation + audio playback
- Namaz times using Aladhan API (auto + manual location)
- Browser notifications for Azan reminders

## How to run
1. `npm install`
2. `npm run dev`
3. Open `http://localhost:5173` in browser

## Deploy
Push to GitHub and use Netlify/Vercel for hosting.

